<template >
    <div>
          <div class="section-authentication-signin d-flex align-items-center justify-content-center">
        <div class="container">
            <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-2">
                <div class="col mx-auto">
                    <div class="card">
                        <div class="card-body">
                            <div class="p-4 rounded  border">
                                <div class="text-center">
                                    <img src="https://dzfullstack.com/assets/images/logo-img.png" width="120" alt="">
                                </div>
                                <div class="mt-2">
                                    <h4 class="mt-3 font-weight-bold text-center">Đổi Mật Khẩu?</h4>
                                     <p class="text-muted text-center">Nhập lại mật khẩu mới để thay đổi mật khẩu</p>
                                    <div class="mb-3 mt-3">
                                        <label class="form-label">Mật khẩu mới</label>
                                        <input  type="text" class="form-control" placeholder="Nhập mật khẩu của bạn">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Xác nhận mật khẩu</label>
                                        <input  type="text" class="form-control" placeholder="Nhập lại mật khẩu của bạn">
                                    </div>
                                    <div class="d-grid gap-2">
                                        <button  type="button" class="btn btn-primary">Thay
                                            đổi mật khẩu</button>
                                       
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style >
    
</style>