<template>
    <div class="overlay toggle-icon"></div>
       <footer class="page-footer">
        <p class="mb-0">Copyright © 2021. All right reserved.</p>
    </footer>
</template>
<script>
export default {

}
</script>
<style>

</style>