import { createRouter, createWebHistory } from "vue-router"; // cài vue-router: npm install vue-router@next --save

const routes = [
    {
        path : '/NhanVien',
        component: ()=>import('../components/admin/nhanvien/index.vue')
    },
    {
        path : '/phong',
        component: ()=>import('../components/admin/loaiphong/index.vue')
    },
    {
        path : '/phanquyen',
        component: ()=>import('../components/admin/phanquyen/index.vue')
    },
    {
        path : '/Thong-Ke',
        component: ()=>import('../components/admin/ThongKe/index.vue')
    },

    //blank
     {
        path : '/Dang-Nhap',
        component: ()=>import('../components/admin/DangNhap/index.vue')
    },
     {
        path : '/Quen-Mat-Khau',
        component: ()=>import('../components/admin/QuenMatKhau/index.vue')
    },
   
]

const router = createRouter({
    history: createWebHistory(),
    routes: routes
})

export default router